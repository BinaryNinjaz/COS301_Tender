TEAM NAME: 
  Binary Ninjaz

TEAM MEMBERS:
  Letanyan Delon Arumugam (u14228123)
  Sizo Duma (u15245579)
  John Ojo (u15096794)
  Kevin Reid (u15008739)
  Shaun Yates (u16007493)
  Teboho Mokoena (u14415888)
  
PROJECT PREFERENCE:
1.  EPI-USE - NFC Bussiness Cards
2.  EPI-USE - Consultant Tracker
3.  Subtrop - Harvest_2018
